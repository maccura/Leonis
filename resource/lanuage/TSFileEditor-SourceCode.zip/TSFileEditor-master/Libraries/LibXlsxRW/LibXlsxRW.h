#ifndef LIBXLSXRW_H
#define LIBXLSXRW_H

#include "libxlsxrw_global.h"
#include "xlsx/xlsxdocument.h"
class LIBXLSXRWSHARED_EXPORT LibXlsxRW
{

public:
    LibXlsxRW();
};

#endif // LIBXLSXRW_H
